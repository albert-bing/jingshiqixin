package nuc.bsd.psy.base.model;

import java.util.Date;

public class Que {

	private String classId;
	private String gradeId;
	private String schoolId;
	private String startTime;
	
	private String paperCode;
	private String stuId;
	private int recId;
	private int part;//量表编码
	private String code;//题目的编号
	private String stem;//题干
	private int optionNumber;//选项个数
	private int ans;//答案
	private int seq;
	
	
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getStuId() {
		return stuId;
	}
	public void setStuId(String stuId) {
		this.stuId = stuId;
	}
	public String getPaperCode() {
		return paperCode;
	}
	public void setPaperCode(String paperCode) {
		this.paperCode = paperCode;
	}
	
	public String getClassId() {
		return classId;
	}
	public void setClassId(String classId) {
		this.classId = classId;
	}
	public String getGradeId() {
		return gradeId;
	}
	public void setGradeId(String gradeId) {
		this.gradeId = gradeId;
	}
	public String getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(String schoolId) {
		this.schoolId = schoolId;
	}
	public int getRecId() {
		return recId;
	}
	public void setRecId(int recId) {
		this.recId = recId;
	}
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getStem() {
		return stem;
	}
	public void setStem(String stem) {
		this.stem = stem;
	}
	public int getOptionNumber() {
		return optionNumber;
	}
	public void setOptionNumber(int optionNumber) {
		this.optionNumber = optionNumber;
	}
	public int getAns() {
		return ans;
	}
	public void setAns(int ans) {
		this.ans = ans;
	}
	public int getPart() {
		return part;
	}
	public void setPart(int part) {
		this.part = part;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	@Override
	public String toString() {
		return "Que [classId=" + classId + ", gradeId=" + gradeId
				+ ", schoolId=" + schoolId + ", recId=" + recId + ", part="
				+ part + ", code=" + code + ", stem=" + stem
				+ ", optionNumber=" + optionNumber + ", ans=" + ans + ", seq="
				+ seq + "]";
	}
	
	
}
