package nuc.bsd.psy.exam.controller;

import org.apache.log4j.Logger;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;

import nuc.bsd.psy.base.model.User;
import nuc.bsd.psy.config.Constant;
public class AuthInterceptor implements Interceptor {
	
	private final static Logger LOGGER = Logger.getLogger(AuthInterceptor.class);
	@SuppressWarnings("unused")
	@Override
	public void intercept(Invocation inv) {
		// TODO Auto-generated method stub
		Controller controller = inv.getController();
	    User loginUser = controller.getSessionAttr("user");
	    if (loginUser != null || inv.getActionKey().equals("/partone/logon")) {
	    	inv.invoke();
	    }else if (loginUser != null || inv.getActionKey().equals("/parttwo/sendPBTest")) {
	    	inv.invoke();
	    	controller.redirect(Constant.noAuthorityPagePath);
		}else if (loginUser != null || inv.getActionKey().equals("/partthree/sendPBTest")) {
	    	inv.invoke();
	    	controller.redirect(Constant.noAuthorityPagePath);
	    }else if(loginUser == null && inv.getActionKey().equals("/partone")){
	    	LOGGER.info("未授权登录被拦截3");
	    	controller.redirect(Constant.AuthorityPagePath);
	    }else{
	    	LOGGER.info("未授权登录被拦截4");
	    	controller.redirect(Constant.noAuthorityPagePath);
	    }
	    if ( inv.getActionKey().equals("/partone/submitPaper")) {
	    	inv.invoke();
	    	
	    }
	    if ( inv.getActionKey().equals("/parttwo/submitPaper")) {
	    	inv.invoke();
	    	
	    }
	    if ( inv.getActionKey().equals("/partthree/submitPaper")) {
	    	inv.invoke();
	    	
	    }
	    
	}
}
