package nuc.bsd.psy.exam.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import nuc.bsd.psy.base.model.Paper;
import nuc.bsd.psy.base.model.Que;
import nuc.bsd.psy.base.model.User;
import nuc.bsd.psy.exam.service.PartOneQuestionService;
import nuc.bsd.psy.exam.service.PartTwoQuestionService;

import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.log.Log;

public class PartTwoExamController extends Controller {
	private final static Logger LOGGER = Logger.getLogger(PartFourExamController.class);
    private final static Log LOG = Log.getLog(PartFourExamController.class);
	/**
	 * 默认首页方法
	 */
	public void index() {
		//render("zhunkaozheng.html");
		render("/Views/PartTwo/pbTest.html");
	}
	
	public void reqPartTwo() {
		User user = getSessionAttr("user");
		LOGGER.info("log4j info1=="+user.getAccount()+"提取《问题行为》题目-parttwo部分");
        LOG.debug("log4j debug2");
        renderText("log");
		List<Que> ques = new PartTwoQuestionService().getPartTwoQuestions(user);
		// 将list打为乱序
		Collections.shuffle(ques);
		Iterator<Que> it = ques.iterator();
		List<Que> que_s = new ArrayList<Que>();
		while(it.hasNext()){
			que_s.add(it.next());
		}
		//System.out.println(que_s);
		renderJson(que_s);
	}
	
	public void submitPaper(){
		
		boolean isSuccess = true;
		try {
		User user = getSessionAttr("user");
		String jsonStr = HttpKit.readData(getRequest());
		List<Paper> papers = new ArrayList<Paper>();
		if(jsonStr!=null && jsonStr.length()!=0){		
		String[] ans = jsonStr.substring(1, jsonStr.length()-2).split(",");
		for(int i=0; i<ans.length; i++){
			Paper paper = new Paper();
			String[] tmp = ans[i].substring(1,ans[i].length()-1).split(":");
			paper.setQueCode(tmp[0]);
			paper.setQueAns(Integer.parseInt(tmp[1]));  
			paper.setClassId(tmp[2]);
			paper.setGradeId(tmp[3]);
			paper.setSchoolId(tmp[4]);
			paper.setPaperCode(tmp[5]);
			paper.setStuId(tmp[6]);
			paper.setStartTime(tmp[7]);
			papers.add(paper);
		}
			new PartTwoQuestionService().savePartTwoAnswers(papers);
		}
		LOGGER.info("log4j info1=="+user.getAccount()+"提交试卷《问题行为》题目-parttwo部分");
        LOG.debug("log4j debug2");
        renderText("log");
		}catch(Exception ex) {
			isSuccess = false;
			ex.printStackTrace();
			
		}
		
		if (isSuccess == true) {
			setAttr("code", 0);
		}else if(isSuccess == false) {
			
			setAttr("code", 1);
		}
		
		renderJson();
	}
	 
}
