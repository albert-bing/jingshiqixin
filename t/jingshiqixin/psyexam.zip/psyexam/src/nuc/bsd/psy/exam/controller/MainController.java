package nuc.bsd.psy.exam.controller;

import org.apache.log4j.Logger;

import com.jfinal.core.Controller;
import com.jfinal.log.Log;

public class MainController extends Controller {
	private final static Logger LOGGER = Logger.getLogger(MainController.class);
    private final static Log LOG = Log.getLog(MainController.class);
	/**
	 * 默认首页方法
	 */
	public void index() {
		/*log.info("success");*/
		//render("zhunkaozheng.html");
		render("/Views/index.html");
	}

}
