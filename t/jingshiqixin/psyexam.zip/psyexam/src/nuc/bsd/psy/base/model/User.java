package nuc.bsd.psy.base.model;

public class User {
	
		private int recId;
		private String account;
		private String pass;
		private String stuId;
		private String classId;
		private String gradeId;
		private String schoolId;
		private String paperCode;
		private int part;
		private String startTime;
		private String option_n;
		private int p_finsih;// 是否完成题目
		private int c_finish;// 家长和学生是否完成
		
		
		public int getP_finsih() {
			return p_finsih;
		}
		public void setP_finsih(int p_finsih) {
			this.p_finsih = p_finsih;
		}
		public int getC_finish() {
			return c_finish;
		}
		public void setC_finish(int c_finish) {
			this.c_finish = c_finish;
		}
		public String getOption_n() {
			return option_n;
		}
		public void setOption_n(String option_n) {
			this.option_n = option_n;
		}
		public String getStartTime() {
			return startTime;
		}
		public void setStartTime(String startTime) {
			this.startTime = startTime;
		}
		public int getPart() {
			return part;
		}
		public void setPart(int part) {
			this.part = part;
		}
		public String getStuId() {
			return stuId;
		}
		public void setStuId(String stuId) {
			this.stuId = stuId;
		}
		public int getRecId() {
			return recId;
		}
		public void setRecId(int recId) {
			this.recId = recId;
		}
		public String getAccount() {
			return account;
		}
		public void setAccount(String account) {
			this.account = account;
		}
		public String getPass() {
			return pass;
		}
		public void setPass(String pass) {
			this.pass = pass;
		}
		
		public String getClassId() {
			return classId;
		}
		public void setClassId(String classId) {
			this.classId = classId;
		}
		public String getGradeId() {
			return gradeId;
		}
		public void setGradeId(String gradeId) {
			this.gradeId = gradeId;
		}
		public String getSchoolId() {
			return schoolId;
		}
		public void setSchoolId(String schoolId) {
			this.schoolId = schoolId;
		}
		public String getPaperCode() {
			return paperCode;
		}
		public void setPaperCode(String paperCode) {
			this.paperCode = paperCode;
		}
		@Override
		public String toString() {
			return "User [recId=" + recId + ", account=" + account + ", pass="
					+ pass + ", stuId=" + stuId + ", classId=" + classId
					+ ", gradeId=" + gradeId + ", schoolId=" + schoolId
					+ ", paperCode=" + paperCode + ", part=" + part
					+ ", startTime=" + startTime + ", option_n=" + option_n
					+ ", p_finsih=" + p_finsih + "]";
		}
		}
