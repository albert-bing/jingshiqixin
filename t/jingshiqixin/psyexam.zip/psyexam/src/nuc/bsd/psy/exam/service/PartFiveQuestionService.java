package nuc.bsd.psy.exam.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;

import nuc.bsd.psy.base.model.Paper;
import nuc.bsd.psy.base.model.Que;
import nuc.bsd.psy.base.model.User;
import nuc.bsd.psy.domain.DbTester;
import nuc.bsd.psy.tools.DateUtil;
/**
 * 家长的试卷的提取和提交
 * @author bing
 *
 */
public class PartFiveQuestionService {

	/**
	 * 家长的的试卷的提取
	 * @param user
	 * @return
	 */
	public List<Que> getPartFiveQuestions(User user) {
		
				List<Que> ques = new ArrayList<Que>();
				String startTime = DateUtil.format(new Date());
				user.setStartTime(startTime);
				StringBuffer sb = new StringBuffer();
					sb.append("select DISTINCT b.id as recId,b.content as stem,b.question_code as code,b.option_number as optionNumber ,part from test_table a left join question_bank b on a.question_code = b.question_code where a.EC_code = ? and a.option_number = 5 and part = 40 and op_type_G = 1");	
				List<Record> records = Db.find(sb.toString(),user.getPaperCode());
				for(Record record : records) {
					Que que = new Que();
					que.setRecId(record.getInt("recId"));
					que.setCode(record.getStr("code"));
					que.setStem(record.getStr("stem"));
					que.setOptionNumber(record.getInt("optionNumber"));
					que.setPart(record.getInt("part"));
					que.setAns(0);
					ques.add(que);
				}
				return ques;
	}
	/**
	 * 家长的试卷的提交
	 * @param papers
	 * @return
	 */
	public boolean savePartFiveAnswers(List<Paper> papers) {
		StringBuffer sb = new StringBuffer();
		sb.append("insert into answer(paperCode,stuId,queCode,queAns,queSeq,submitTime,schoolId,gradeId,classId,startTime) values(?,?,?,?,?,?,?,?,?,?)");
		Object[][]paras = new Object[papers.size()][10];
		int i = 0;
		String currentTime = DateUtil.format(new Date());
		for(Paper paper : papers) {
			paras[i]=new Object[] {paper.getPaperCode(),paper.getStuId(),paper.getQueCode(),paper.getQueAns(),0,currentTime,paper.getSchoolId(),paper.getGradeId(),paper.getClassId(),paper.getStartTime()};
			i++;
		}
		StringBuffer is_sb = new StringBuffer();
		is_sb.append("update stu_paper set p_finish = 1 where studentNO = ? and dis_time in (select id from paper_stu where classID = ? and paper_code = ?)");
		
		// 数据入库(1)
		Db.batch(sb.toString(), paras, papers.size());
		// 更新分配表的is_finish字段
		Db.update(is_sb.toString(), papers.get(0).getStuId(),papers.get(0).getClassId(), papers.get(0).getPaperCode());
		//System.out.println(papers.get(0).getPaperCode());
		return true;
	}

}
