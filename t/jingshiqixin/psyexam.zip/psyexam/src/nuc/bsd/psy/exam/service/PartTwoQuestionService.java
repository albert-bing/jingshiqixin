package nuc.bsd.psy.exam.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;

import nuc.bsd.psy.base.model.Paper;
import nuc.bsd.psy.base.model.Que;
import nuc.bsd.psy.base.model.User;
import nuc.bsd.psy.domain.DbTester;
import nuc.bsd.psy.tools.DateUtil;

public class PartTwoQuestionService {

	
	public List<Que> getPartTwoQuestions(User user) {
		
				List<Que> ques = new ArrayList<Que>();
				
				StringBuffer sb = new StringBuffer();
				sb.append("select distinct b.id as recId,b.content as stem,b.question_code as code,b.option_number as optionNumber from test_table a left join question_bank b on a.question_code = b.question_code where a.EC_code = ? and a.option_number = 4");	
				List<Record> records = Db.find(sb.toString(), user.getPaperCode());
				for(Record record : records) {
					Que que = new Que();
					que.setRecId(record.getInt("recId"));
					que.setCode(record.getStr("code"));
					que.setStem(record.getStr("stem"));
					que.setOptionNumber(record.getInt("optionNumber"));
					// 将学校、年级和班级存入que中
					que.setClassId(user.getClassId());
					que.setGradeId(user.getGradeId());
					que.setSchoolId(user.getSchoolId());
					que.setPaperCode(user.getPaperCode());
					que.setStuId(user.getStuId());
					que.setStartTime(user.getStartTime());
					que.setAns(0);
					ques.add(que);
				}
				return ques;
	}
	public boolean savePartTwoAnswers(List<Paper> papers) {
		StringBuffer sb = new StringBuffer();
		sb.append("insert into answer(paperCode,stuId,queCode,queAns,submitTime,schoolId,gradeId,classId,startTime) values(?,?,?,?,?,?,?,?,?)");
		Object[][]paras = new Object[papers.size()][9];
		int i = 0;
		String currentTime = DateUtil.format(new Date());
		for(Paper paper : papers) {
			paras[i]=new Object[] {paper.getPaperCode(),paper.getStuId(),paper.getQueCode(),paper.getQueAns(),currentTime,paper.getSchoolId(),paper.getGradeId(),paper.getClassId(),paper.getStartTime()};
			i++;
		}
		StringBuffer is_sb = new StringBuffer();
		is_sb.append("update stu_paper set c_finish ='1' where studentNO = ? and dis_time in (select id from paper_stu where classID = ? and paper_code = ?)");
		
		// 数据入库(1)
		Db.batch(sb.toString(), paras, papers.size());
		// 更新分配表的is_finish字段
		Db.update(is_sb.toString(), papers.get(0).getStuId(),papers.get(0).getClassId(),papers.get(0).getPaperCode());
		//System.out.println(papers.get(0).getPaperCode());
		return true;
	}

}
